---
name: appreneur-blueprint
description: Take an app idea from "should I build this" to a sellable product. Use for validating ideas, writing a PRD, planning Lovable build batches, hardening, packaging, and listing an app for sale.
---

# Appreneur Blueprint

The Appreneur method: non-coders building real apps as sellable products using staged prompts and Proprietary Source Architecture (PSA) licensing. Every app moves through six stages in order:

**VALIDATE → BLUEPRINT → BUILD → HARDEN → PACKAGE → SELL**

Skipping stages is how half-finished apps pile up. Building is cheap now. Finishing is the scarce skill.

Write for a non-technical business owner. Define every term the first time it appears. Show the exact prompt or screen instead of describing it. If the user has a personal voice skill installed, write all customer-facing copy through it.

## Stage 0: The portfolio gate

Before validating a new idea, ask the user one question: **what does this displace, or what launch does it wait behind?** Most people's real constraint is selling, not building. If the honest answer is "it stacks on top of everything else I haven't launched," the idea goes in a parking lot with a one-paragraph brief. Write the brief, park it, move on.

## Stage 1: Validate

Score the idea 1-10 on each line, with one sentence of evidence per line:

1. **Painful problem:** would 10 specific people pay for this within a week of seeing it? Name the kind of person.
2. **Reachable buyer:** can you name where they already gather (a group, a niche, a list)? "Everyone" fails this.
3. **Monetization path:** one-time PSA sale, SaaS subscription, or a service-enabler you use to sell your own services? Pick the primary path now.
4. **Buildable scope:** fits Lovable + Supabase in a bounded number of batches. If it needs infrastructure Lovable can't host, it's a different kind of project.
5. **Differentiation:** what makes this a category of one instead of a clone?

Kill below 30/50, or if any single line scores 3 or less. Killing fast is a win; say so plainly. Passing ideas get a one-page validation brief: the five scores, the buyer, the price hypothesis, and the displacement answer from Stage 0.

## Stage 2: Blueprint (the prompt sequence)

A staged prompt sequence where each stage's output feeds the next verbatim. Produce all five documents before the first build prompt is sent:

1. **Concept brief:** the transformation, the user, the 3 core jobs the app does. One page.
2. **PRD:** user types, jobs-to-be-done, data model (tables and columns), page list, edge functions needed, integrations. This is the contract the build is graded against.
3. **Design system prompt:** colors, type pairing, spacing, and the app's signature element (one distinctive, structural design move; every product gets one).
4. **Build batches:** numbered, single-concern batches. Each one states exact scope, exact files, "keep everything else identical," and ends with "Typecheck when done." Sequence so nothing depends on something not built yet.
5. **Hardening plan:** the checklist this app must pass before anyone calls it done (see Stage 4).

## Stage 3: Build

Execute the batches one at a time in Lovable. Rules:

- One concern per batch. Never mix security, email, and UI polish in one prompt.
- Paste the batch prompt exactly. Wait for it to finish. Check the preview before sending the next one.
- If a batch breaks the app, send this rollback prompt verbatim:

```
The last change broke the app. Do not add features. Diagnose and repair only.

Identify what changed in the last step and what errors appear in build/preview/logs. Fix the regression and nothing else. Return a summary of the root cause and the repair.
```

If the user has the **lovable-production** skill installed, that skill governs how batches are written and verified. This skill is the what and the order; that one is the how.

## Stage 4: Harden

An app is not sellable until these are clean:

- No API keys or secrets in frontend code.
- Every table holding personal data has a `user_id` column and row-level security (RLS) so users only see their own rows.
- Edge functions that touch personal data require the user to be logged in.
- Every visible screen actually works with real data (no empty sections, broken images, or dead buttons).
- Optional features degrade gracefully when not configured, instead of crashing.

Run a final QA prompt as the last batch. After it finishes, read the security-critical files yourself (or have Claude read them) instead of trusting the summary. A PSA with a security hole isn't a product, it's a liability you handed to a customer.

## Stage 5: Package as a PSA

Say Proprietary Source Architecture, never "template." A complete PSA package contains:

1. **Full source** with a clean repo state.
2. **README:** what it does, required and optional secrets (names and where to set them), deployment steps, what to verify before trusting it with real data.
3. **Schema doc** generated from the real database so it matches reality.
4. **Demo instance** with seeded example data. Rotate credentials after recording.
5. **Walkthrough video (5-10 minutes):** what it does, the buyer's first hour, where the levers are.
6. **License terms:** state plainly what the buyer gets (full ownership of their copy is the standard) and what they can't do (resell the resell rights).
7. **Positioning one-liner:** who it's for + the outcome, in one sentence.

## Stage 6: Sell

Listing requirements, whether it's a marketplace like PushTen or your own sales page: outcome-first title (the buyer's result, not the tech), the positioning one-liner, 4-6 screenshots of the money screens, a demo link, a what's-included list mirroring the package contents, a price consistent with the market, and the license terms stated plainly.

The listing is a shelf. The launch is what sells. After the listing is up, the next job is finding the first 10 buyers (the **first-customer-finder** skill does this if installed) and running a real launch.

## Output rules

- Lead with the verdict or the deliverable. Explain after.
- Short paragraphs. Numbers as digits.
- When the user is at Stage 1, do not write a PRD. When at Stage 3, do not redesign. Stay in the stage.
- End every session with: what's done, what stage is next, and the single next action.
