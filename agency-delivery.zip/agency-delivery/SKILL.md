---
name: agency-delivery
description: Client delivery system for websites and apps built for clients. Use for discovery, proposals, scoping, the 3-batch build, client updates, QA, launch checklists, handoff, testimonials, and care plans.
---

# Agency Delivery

The repeatable system for taking a client from first conversation to launched site to retained relationship. Use it for every client project so the process is the same each time and only the client changes.

If the user has the **lovable-production** skill installed, builds run through it (batching, verification, security). This skill is the client-facing wrapper: what happens before, around, and after the build.

Write for a non-technical agency owner. Define terms the first time they appear. Every output should be clean enough to hand to a client or a new team member as-is.

## Discovery (one call or one form, never a drag)

Get these answered and write them into a discovery brief the same day:

1. What does the business actually sell, and to whom?
2. The #1 conversion action the site exists to produce (call, form, booking, purchase). One primary. Everything on the site serves it.
3. Brand assets that exist: logo, colors, photos, copy. What's real vs. what we're creating.
4. Three sites they envy and one they hate, with why.
5. Must-keep content from the current site, if any.
6. Deadline, and what's driving it.
7. Who approves, and who else has opinions. (These are different people more often than not. Find out now.)

## Scope and proposal

Fixed scope, written down: exact page list, integrations, what's included, what's explicitly excluded, timeline expressed in batches, revision policy (2 rounds per batch; more is a change order), price, and payment terms (half up front is the default).

The proposal's job is to make "yes" easy and scope-creep conversations short. Keep it to 2 pages unless the client asks for more.

## The 3-batch build

Each batch ends with the client seeing something real.

- **Batch 1 - Foundation.** Design system (colors, fonts, spacing), nav and footer, hero, homepage skeleton. The client sees the direction while it's cheap to steer. Approval on Batch 1 locks the look; say so when sending it.
- **Batch 2 - Core.** Every inner page, real content in place (never placeholder text to a client), forms wired end to end, integrations connected. Forms include compliance details: SMS consent language on anything that collects a phone number is verified, not assumed.
- **Batch 3 - Signature and polish.** The signature element, micro-interactions, full mobile pass, speed, and SEO/social-preview basics. The social preview image (og:image) is a repeat offender: check it renders in an actual link preview, don't assume.

## The signature element doctrine

Every site gets exactly one distinctive, memorable design move. Rules:

- It's derived from the client's world, not imported taste. (A mountain guide gets an elevation-based navigation rail. A bakery gets ghosted product moments that appear as you scroll.)
- It's structural, not decorative. It organizes or navigates; it doesn't just sparkle.
- There's only one.

The signature element is what the client shows their friends. It's also what separates the work from the templated look of everyone else's AI-built sites.

## Client communication cadence

- **Batch-end video** (3-5 minutes, Loom or similar) walking what shipped, plus a one-line status message: what shipped, what's next, what's needed from them.
- **Approvals in writing.** A thumbs-up emoji on the video counts. Silence doesn't.
- **Scope-creep script:** "Love that idea. That's a great Batch 4 item. Want me to price it?" Warm, immediate, and it converts creep into revenue instead of resentment.
- **Bad news early.** A slipped date reported the day it slips costs almost nothing. Discovered at the deadline, it costs the relationship.

## QA and launch checklist

Run before the client ever hears the word "done."

1. Every form submits and routes to a real inbox that was actually checked. Test with a real submission.
2. Analytics firing and verified in the dashboard, not just installed.
3. Social preview image, favicon, page titles, meta descriptions: check the link preview for real.
4. Full mobile pass: nav, tap targets, forms, hero on a real phone.
5. 404 page exists; dead links crawled and fixed.
6. Domain, SSL, and www/non-www redirect correct.
7. Legal pages present (privacy, terms) and linked in the footer.
8. Speed sanity check; compress anything embarrassing.
9. Every core flow listed in the scope clicked through, live.

## Handoff

Handoff is a package, not a password: credentials transferred properly, a how-to-edit doc for the things they'll actually touch, a 5-minute training video, and the "who to call" line.

Then two asks, timed at the launch high while they're thrilled:

- **The testimonial.** Make it effortless: "Can I send you 3 questions to react to?"
- **The care plan.** Monthly retainer: updates, monitoring, small changes, priority response. The pitch is one paragraph, because the launch experience already made the argument.

## Voice rules for client work

Site copy matches the **client's** voice, not the agency's. If the user has a personal voice skill, it governs their own brand only, never a client site. The hygiene layer applies everywhere: no AI-tell patterns, no filler phrases, concrete over vague. A client site that reads like a robot wrote it undoes everything the signature element earned.

## Output rules

- When asked for a proposal, produce the proposal, not advice about proposals.
- When asked for a checklist, produce it as a checklist the user can copy into their project tool.
- End with the next action and who owns it (agency or client).
