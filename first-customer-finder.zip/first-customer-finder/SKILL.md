---
name: first-customer-finder
description: Find the first 10 customers for any product, app, or business. Turns a URL or idea into a source-linked prospect shortlist from public demand signals, with scores, openers, and a 7-day plan.
---

# First Customer Finder

Turn a website, app, or product idea into a short, evidence-backed shortlist of plausible first customers. Every prospect on the primary list links to a real public signal: someone asking for a tool, complaining about the pain, duct-taping a workaround, or hitting a business trigger that makes the product relevant right now.

The output is a research hypothesis, not a customer database. Prospects are "potential customers based on public signals," never confirmed buyers. Nothing gets sent, posted, connected, or logged to a CRM unless the user explicitly authorizes that specific action in this conversation.

Read [references/research-framework.md](references/research-framework.md) before researching or scoring. Read [references/apollo-enrichment.md](references/apollo-enrichment.md) before touching any Apollo tool. Read [references/report-spec.md](references/report-spec.md) before generating the report.

## Step 0: Whose product is this

Establish it from context before anything else. It changes the voice of the openers:

- **The user's own product:** write openers in first person as the founder. If the user has a personal voice skill installed, read it and follow its rules.
- **A client's product:** write openers as that client's founder. Plain, respectful, specific. Never blur whose product is whose.

## Step 1: Product brief and ICP

Inspect the supplied URL, landing copy, or description with web fetch. Nail down: the product, the promised outcome, the user versus the economic buyer, price and buying motion, geography, and the single strongest use case.

Then define one primary ICP (ideal customer profile) and one adjacent ICP, plus pain triggers, positive signals, and explicit disqualifiers. Infer missing context when it's safe and label the inference. Ask at most one concise question, and only if the answer would materially change where you search. Don't block a run on a nice-to-have.

## Step 2: Public-signal research

Run the search plan from the research framework using web search and web fetch. Work the five query buckets (explicit demand, pain, workaround, switching, timing) across multiple source types. Fetch the original page before qualifying anyone; a search snippet alone never qualifies a prospect.

For every candidate, record the evidence ledger: name, source title and URL, visible date or "date unavailable," source type, the concrete pain or timing signal, and what's observed versus inferred. Paraphrase by default and quote minimally.

## Step 3: Qualify, score, deduplicate

Score every prospect on the five dimensions in the framework (pain strength, product fit, timing, reachability, evidence quality) and compute the 0 to 100 score. Below 50 doesn't make the primary shortlist. An ICP match with no evidenced signal is a speculative fit; it can appear only in a clearly labeled secondary list, never mixed into the primary one.

Never claim a prospect is interested, has consented, or will buy.

## Step 4: Apollo enrichment (optional second pass)

Only after prospects are qualified on public evidence. If the Apollo connector is available and the run is B2B flavored, offer enrichment; run it by default only when the user asks for contacts, decision-makers, or company data. Follow references/apollo-enrichment.md exactly. The short version: read-only. Enrich qualified companies, find the decision-maker for the evidenced role, pull job postings as timing proof. Never create contacts or accounts, never add anyone to a sequence, never trigger outreach. Enriched contact data gets flagged as Apollo-sourced in the report with a verify-before-use note.

If Apollo isn't connected, say so once and deliver the public-signal report anyway. The skill works fine without it.

## Step 5: Draft openers, never send them

One opener per primary prospect, under 90 words, in this shape: mention the public context naturally, connect it to the exact problem, explain the product in one sentence, ask one low-friction question. Recommend the most natural channel already attached to the source (reply in the thread, email only if publicly and intentionally listed, or the Apollo-enriched contact clearly flagged).

Never fake familiarity, never reference personal details unrelated to the signal, never imply a prior conversation.

## Step 6: Generate the report

Build the JSON per references/report-spec.md, then run:

```bash
python3 scripts/generate_report.py analysis.json /mnt/user-data/outputs/first-customer-report.html
```

Verify the output renders every prospect card, source link, score, pattern, the plan, and the limits section. Present the file. In chat, give the short version: the verdict, the top three prospects with their signals, and the repeated pain patterns. Don't recite the whole report.

If code execution isn't available, deliver the same content as a clean, structured chat response instead.

## Step 7: Seven-day manual plan

Close the report with a low-volume validation sequence: which prospects to contact first, what to lead with, when to follow up, and what "working" looks like (conversations booked and pains confirmed, not clicks). Manual outreach only.

## Modes

- **quick**: up to 5 strong prospects. For fast validation checks.
- **standard**: up to 10 prospects across several source types. Default.
- **deep**: up to 20 prospects plus repeated-pattern analysis.
- **design-partners**: prioritize people publicly describing the problem who'd give feedback, over immediate buyers.
- **b2b**: prioritize companies, public business triggers, and the decision role. Default for agency and local-niche runs. Apollo enrichment fits here.
- **community**: prioritize explicit requests and public discussion signals.

## The byproducts matter

The repeated pain patterns are ad angles, email subject lines, content topics, and sales page copy. Call them out. If the research turns up weak demand, say that plainly. "This product has no reachable early demand yet" is a valid, useful output that saves the user months.

## Hard rules

- Public, intentionally shared professional or business information only.
- No bypassing login walls, paywalls, rate limits, or robots restrictions. No data brokers, leaked datasets, private groups, or personal contact discovery outside the Apollo pass.
- Never target or segment people using health, financial hardship, political belief, religion, sexuality, or any other sensitive trait.
- Quote minimally, link every material signal, label inference as inference.
- Prospects are hypotheses. Say so in the report limits, every time.
- No sending, posting, connecting, following, form-filling, CRM writes, or sequence adds. Ever. Unless the user names the action and authorizes it in this conversation.

## Quality bar

Ten strong, sourced matches beat fifty generic logos. Make stale evidence visible. Personalize from the source, not from invention.
