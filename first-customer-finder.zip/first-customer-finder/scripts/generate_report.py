#!/usr/bin/env python3
"""Generate a standalone First Customer Finder HTML report from analysis JSON.

Usage:
    python3 scripts/generate_report.py analysis.json output.html
"""

from __future__ import annotations

import argparse
import html as html_lib
import json
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

DIMENSION_LABELS = [
    ("pain_strength", "Pain"),
    ("product_fit", "Fit"),
    ("timing", "Timing"),
    ("reachability", "Reach"),
    ("evidence_quality", "Evidence"),
]


def esc(value: Any) -> str:
    return html_lib.escape(str(value if value is not None else ""), quote=True)


def clamp(value: Any, hi: int) -> int:
    try:
        n = round(float(value))
    except (TypeError, ValueError):
        n = 0
    return max(0, min(hi, n))


def as_list(value: Any) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def link(url: Any) -> str:
    raw = str(url or "").strip()
    p = urlparse(raw)
    if p.scheme in ("http", "https") and p.netloc:
        return esc(raw)
    return "#"


def tier(score: int) -> str:
    if score >= 80:
        return "strong"
    if score >= 65:
        return "warm"
    return "cool"


def stage_cls(stage: Any) -> str:
    s = str(stage or "").lower()
    if "high" in s:
        return "stage-hot"
    if "problem" in s or "trigger" in s:
        return "stage-warm"
    return "stage-cool"


def dim_bars(dims: dict) -> str:
    cells = []
    for key, label in DIMENSION_LABELS:
        v = clamp(dims.get(key, 0), 5)
        cells.append(
            f'<div class="dim"><span class="dim-label">{label}</span>'
            f'<span class="dim-track"><span class="dim-fill" style="width:{v * 20}%"></span></span>'
            f'<span class="dim-num">{v}</span></div>'
        )
    return f'<div class="dims">{"".join(cells)}</div>'


def enriched_block(en: dict) -> str:
    if not isinstance(en, dict) or not en:
        return ""
    rows = []
    for key, label in [
        ("title", "Title"), ("company", "Company"), ("headcount", "Headcount"),
        ("industry", "Industry"), ("location", "Location"), ("email", "Email"),
    ]:
        if en.get(key):
            rows.append(f'<span class="en-item"><b>{label}:</b> {esc(en[key])}</span>')
    if en.get("linkedin_url"):
        rows.append(f'<span class="en-item"><b>LinkedIn:</b> <a href="{link(en["linkedin_url"])}" target="_blank" rel="noopener">profile</a></span>')
    note = esc(en.get("note") or "Apollo-enriched. Verify before outreach.")
    return (
        '<div class="enriched"><div class="en-head">Enriched contact</div>'
        f'<div class="en-grid">{"".join(rows)}</div>'
        f'<div class="en-note">{note}</div></div>'
    )


def prospect_card(p: dict, featured: bool = False) -> str:
    score = clamp(p.get("score"), 100)
    dims = p.get("dimensions") or {}
    date = esc(p.get("signal_date") or "date unavailable")
    src_title = esc(p.get("source_title") or "Source")
    caution = (
        f'<p class="caution"><b>Caution:</b> {esc(p["caution"])}</p>'
        if p.get("caution") else ""
    )
    opener = (
        f'<div class="opener"><div class="opener-label">Suggested opener</div>'
        f'<p>{esc(p["opener"])}</p></div>'
        if p.get("opener") else ""
    )
    channel = (
        f'<p class="channel"><b>Channel:</b> {esc(p["suggested_channel"])}</p>'
        if p.get("suggested_channel") else ""
    )
    cls = "card featured" if featured else "card"
    badge = '<div class="featured-tag">Top prospect</div>' if featured else ""
    return f"""
    <article class="{cls}">
      {badge}
      <header class="card-head">
        <div>
          <h3>{esc(p.get("name") or "Unnamed prospect")}</h3>
          <div class="meta-row">
            <span class="chip">{esc(p.get("type") or "Prospect")}</span>
            <span class="chip {stage_cls(p.get("stage"))}">{esc(p.get("stage") or "Stage unknown")}</span>
          </div>
        </div>
        <div class="score {tier(score)}"><span>{score}</span><small>/100</small></div>
      </header>
      <p class="signal">{esc(p.get("pain_signal") or "")}</p>
      <div class="facts">
        <p><b>Evidence:</b> {esc(p.get("evidence") or "")}</p>
        <p><b>Why fit:</b> {esc(p.get("why_fit") or "")}</p>
        <p><b>Why now:</b> {esc(p.get("why_now") or "")}</p>
      </div>
      <p class="source"><b>Source:</b> <a href="{link(p.get("source_url"))}" target="_blank" rel="noopener">{src_title}</a>
        <span class="src-meta">{esc(p.get("source_type") or "")} &middot; {date}</span></p>
      {dim_bars(dims)}
      {channel}
      {opener}
      {enriched_block(p.get("enriched") or {})}
      {caution}
    </article>"""


def build(data: dict) -> str:
    title = esc(data.get("title") or "First Customer Finder")
    product = esc(data.get("product") or "")
    product_url = link(data.get("product_url"))
    prospects = sorted(
        [p for p in as_list(data.get("prospects")) if isinstance(p, dict)],
        key=lambda p: clamp(p.get("score"), 100),
        reverse=True,
    )
    cards = "".join(
        prospect_card(p, featured=(i == 0)) for i, p in enumerate(prospects)
    ) or '<p class="empty">No prospects met the evidence bar. See the verdict and limits.</p>'

    icp = data.get("icp") or {}
    icp_html = "".join(
        f'<div class="icp-cell"><div class="icp-label">{label}</div><p>{esc(icp.get(key) or "")}</p></div>'
        for key, label in [
            ("primary", "Primary ICP"), ("adjacent", "Adjacent ICP"),
            ("triggers", "Buying triggers"), ("disqualifiers", "Disqualifiers"),
        ] if icp.get(key)
    )

    patterns = "".join(
        f'<div class="pattern"><div class="pat-head"><span class="pat-count">{clamp(pt.get("count"), 999)}&times;</span>'
        f'<h4>{esc(pt.get("title") or "")}</h4></div><p>{esc(pt.get("insight") or "")}</p></div>'
        for pt in as_list(data.get("patterns")) if isinstance(pt, dict)
    )

    plan = data.get("outreach_plan") or {}
    plan_days = "".join(
        f'<div class="day"><span class="day-tag">{esc(d.get("day") or "")}</span><p>{esc(d.get("action") or "")}</p></div>'
        for d in as_list(plan.get("days")) if isinstance(d, dict)
    )
    plan_html = ""
    if plan:
        angle = f'<p class="plan-angle"><b>Angle:</b> {esc(plan["angle"])}</p>' if plan.get("angle") else ""
        success = f'<p class="plan-success"><b>Success looks like:</b> {esc(plan["success"])}</p>' if plan.get("success") else ""
        plan_html = f'<section><h2>Seven-day manual plan</h2>{angle}<div class="days">{plan_days}</div>{success}</section>'

    secondary = as_list(data.get("secondary"))
    secondary_html = ""
    if secondary:
        rows = "".join(
            f'<li><b>{esc(s.get("name") or "")}</b> &mdash; {esc(s.get("reason") or "")} <span class="src-meta">({esc(s.get("source") or "speculative")})</span></li>'
            for s in secondary if isinstance(s, dict)
        )
        secondary_html = f'<section><h2>Secondary list <span class="soft">speculative, no individual signal</span></h2><ul class="secondary">{rows}</ul></section>'

    limits = "".join(f"<li>{esc(x)}</li>" for x in as_list(data.get("limits")))
    pattern_section = f'<section><h2>Repeated pain patterns</h2><div class="patterns">{patterns}</div></section>' if patterns else ""
    icp_section = f'<section><h2>Ideal customer profile</h2><div class="icp-grid">{icp_html}</div></section>' if icp_html else ""

    meta_bits = " &middot; ".join(filter(None, [
        esc(data.get("owner") or ""),
        f'{esc(data.get("mode") or "standard")} mode',
        esc(data.get("search_scope") or ""),
        esc(data.get("generated_at") or ""),
    ]))

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>{title}</title>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root {{
    color-scheme: light dark;
    --ink: #16130e; --ink-soft: #5c5648; --ivory: #faf7f0; --card: #fffdf8;
    --line: #e7e0d2; --gold: #b08d2b; --gold-deep: #8f6f1c; --gold-soft: #f3ead2;
    --warm: #b3641f; --cool: #7a7264;
    --chip-bg: #ffffff; --enrich-bg: #fffcf3;
    --verdict-bg: #16130e; --verdict-text: #faf7f0; --verdict-border: transparent;
  }}
  @media (prefers-color-scheme: dark) {{
    :root {{
      --ink: #f0eadd; --ink-soft: #b8ae9c; --ivory: #14110c; --card: #1d1913;
      --line: #362e21; --gold: #c9a227; --gold-deep: #d9b64a; --gold-soft: #2b2412;
      --warm: #de9257; --cool: #9a9184;
      --chip-bg: #241f16; --enrich-bg: #221c11;
      --verdict-bg: #1d1913; --verdict-text: #f0eadd; --verdict-border: #4a3d20;
    }}
  }}
  * {{ box-sizing: border-box; margin: 0; }}
  body {{ background: var(--ivory); color: var(--ink); font: 16px/1.6 Inter, system-ui, sans-serif; -webkit-font-smoothing: antialiased; }}
  .wrap {{ max-width: 880px; margin: 0 auto; padding: 56px 24px 80px; }}
  h1, h2, h3 {{ font-family: "Instrument Serif", Georgia, serif; font-weight: 400; letter-spacing: .01em; }}
  h1 {{ font-size: 44px; line-height: 1.1; }}
  h2 {{ font-size: 28px; margin: 0 0 18px; padding-top: 8px; border-top: 1px solid var(--line); }}
  section {{ margin-top: 48px; }}
  .soft {{ color: var(--ink-soft); font-size: 15px; font-family: Inter, sans-serif; }}
  .kicker {{ text-transform: uppercase; letter-spacing: .14em; font-size: 12px; font-weight: 600; color: var(--gold-deep); margin-bottom: 12px; }}
  .meta {{ color: var(--ink-soft); font-size: 14px; margin-top: 10px; }}
  .product-link a {{ color: var(--gold-deep); text-decoration: none; border-bottom: 1px solid var(--gold); }}
  .verdict {{ margin-top: 28px; background: var(--verdict-bg); color: var(--verdict-text); border: 1px solid var(--verdict-border); border-radius: 14px; padding: 24px 28px; }}
  .verdict .v-label {{ text-transform: uppercase; letter-spacing: .14em; font-size: 11px; color: var(--gold); font-weight: 600; margin-bottom: 8px; }}
  .verdict p {{ font-family: "Instrument Serif", Georgia, serif; font-size: 24px; line-height: 1.35; }}
  .icp-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }}
  .icp-cell {{ background: var(--card); border: 1px solid var(--line); border-radius: 12px; padding: 16px 18px; }}
  .icp-label {{ font-size: 12px; text-transform: uppercase; letter-spacing: .12em; color: var(--gold-deep); font-weight: 600; margin-bottom: 6px; }}
  .card {{ background: var(--card); border: 1px solid var(--line); border-radius: 14px; padding: 24px; margin-bottom: 18px; position: relative; }}
  .card.featured {{ border: 1.5px solid var(--gold); box-shadow: 0 1px 0 var(--gold-soft), 0 12px 32px rgba(176,141,43,.10); }}
  .featured-tag {{ position: absolute; top: -11px; left: 20px; background: var(--gold); color: #fff; font-size: 11px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; padding: 3px 10px; border-radius: 99px; }}
  .card-head {{ display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; }}
  .card h3 {{ font-size: 26px; }}
  .meta-row {{ display: flex; gap: 8px; margin-top: 6px; flex-wrap: wrap; }}
  .chip {{ font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 99px; border: 1px solid var(--line); color: var(--ink-soft); background: var(--chip-bg); }}
  .stage-hot {{ background: var(--gold); border-color: var(--gold); color: #fff; }}
  .stage-warm {{ border-color: var(--warm); color: var(--warm); }}
  .stage-cool {{ border-color: var(--cool); color: var(--cool); }}
  .score {{ text-align: center; min-width: 74px; border-radius: 12px; padding: 8px 10px 6px; border: 1px solid var(--line); }}
  .score span {{ font-family: "Instrument Serif", Georgia, serif; font-size: 30px; display: block; line-height: 1; }}
  .score small {{ color: var(--ink-soft); font-size: 11px; }}
  .score.strong {{ background: var(--gold-soft); border-color: var(--gold); }} .score.strong span {{ color: var(--gold-deep); }}
  .score.warm span {{ color: var(--warm); }}
  .score.cool span {{ color: var(--cool); }}
  .signal {{ font-family: "Instrument Serif", Georgia, serif; font-size: 20px; line-height: 1.4; margin: 14px 0 10px; }}
  .facts p {{ font-size: 14.5px; margin: 4px 0; color: var(--ink-soft); }}
  .facts b, .source b, .channel b, .caution b {{ color: var(--ink); font-weight: 600; }}
  .source {{ font-size: 14.5px; margin-top: 10px; }}
  .source a {{ color: var(--gold-deep); }}
  .src-meta {{ color: var(--ink-soft); font-size: 13px; }}
  .dims {{ display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin: 14px 0 4px; }}
  .dim {{ font-size: 11px; color: var(--ink-soft); }}
  .dim-label {{ display: block; margin-bottom: 3px; text-transform: uppercase; letter-spacing: .08em; }}
  .dim-track {{ display: block; height: 5px; background: var(--line); border-radius: 99px; overflow: hidden; }}
  .dim-fill {{ display: block; height: 100%; background: var(--gold); border-radius: 99px; }}
  .dim-num {{ font-weight: 600; color: var(--ink); }}
  .channel {{ font-size: 14.5px; margin-top: 10px; }}
  .opener {{ background: var(--ivory); border-left: 3px solid var(--gold); border-radius: 0 10px 10px 0; padding: 12px 16px; margin-top: 12px; }}
  .opener-label {{ font-size: 11px; text-transform: uppercase; letter-spacing: .12em; color: var(--gold-deep); font-weight: 700; margin-bottom: 4px; }}
  .opener p {{ font-size: 15px; }}
  .enriched {{ margin-top: 12px; border: 1px dashed var(--gold); border-radius: 10px; padding: 12px 16px; background: var(--enrich-bg); }}
  .en-head {{ font-size: 11px; text-transform: uppercase; letter-spacing: .12em; color: var(--gold-deep); font-weight: 700; margin-bottom: 6px; }}
  .en-grid {{ display: flex; flex-wrap: wrap; gap: 6px 18px; font-size: 13.5px; }}
  .en-note {{ margin-top: 8px; font-size: 12px; color: var(--warm); font-weight: 600; }}
  .caution {{ margin-top: 12px; font-size: 13.5px; color: var(--warm); }}
  .patterns {{ display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }}
  .pattern {{ background: var(--card); border: 1px solid var(--line); border-radius: 12px; padding: 16px 18px; }}
  .pat-head {{ display: flex; align-items: baseline; gap: 10px; margin-bottom: 6px; }}
  .pat-count {{ font-family: "Instrument Serif", Georgia, serif; font-size: 24px; color: var(--gold-deep); }}
  .pattern h4 {{ font-size: 16px; }}
  .pattern p {{ font-size: 14px; color: var(--ink-soft); }}
  .days {{ margin-top: 8px; }}
  .day {{ display: flex; gap: 14px; align-items: baseline; padding: 10px 0; border-bottom: 1px dashed var(--line); }}
  .day-tag {{ min-width: 84px; font-weight: 700; font-size: 13px; color: var(--gold-deep); text-transform: uppercase; letter-spacing: .06em; }}
  .plan-angle, .plan-success {{ font-size: 15px; margin-top: 10px; }}
  .secondary {{ padding-left: 20px; }} .secondary li {{ margin: 6px 0; font-size: 14.5px; }}
  .limits ul {{ padding-left: 20px; }} .limits li {{ margin: 6px 0; color: var(--ink-soft); font-size: 14.5px; }}
  .footer {{ margin-top: 56px; padding-top: 16px; border-top: 1px solid var(--line); font-size: 12.5px; color: var(--ink-soft); }}
  .empty {{ color: var(--ink-soft); font-style: italic; }}
  @media (max-width: 640px) {{ .icp-grid, .patterns, .dims {{ grid-template-columns: 1fr 1fr; }} h1 {{ font-size: 34px; }} .dims {{ grid-template-columns: repeat(3, 1fr); }} }}
  @media print {{
    :root {{
      color-scheme: light;
      --ink: #16130e; --ink-soft: #5c5648; --ivory: #ffffff; --card: #ffffff;
      --line: #ddd6c6; --gold: #b08d2b; --gold-deep: #8f6f1c; --gold-soft: #f3ead2;
      --warm: #b3641f; --cool: #7a7264;
      --chip-bg: #ffffff; --enrich-bg: #fffcf3;
      --verdict-bg: #16130e; --verdict-text: #ffffff; --verdict-border: transparent;
    }}
    body {{ background: #fff; }}
    .card, .icp-cell, .pattern, .day {{ break-inside: avoid; }}
  }}
</style>
</head>
<body>
<div class="wrap">
  <header>
    <div class="kicker">First Customer Finder</div>
    <h1>{title}</h1>
    <p class="meta product-link">{product}{" &middot; " if product and product_url != "#" else ""}{f'<a href="{product_url}" target="_blank" rel="noopener">{product_url}</a>' if product_url != "#" else ""}</p>
    <p class="meta">{meta_bits}</p>
    <div class="verdict"><div class="v-label">Verdict</div><p>{esc(data.get("verdict") or "")}</p></div>
  </header>
  {icp_section}
  <section>
    <h2>Prospect shortlist <span class="soft">{len(prospects)} evidence-backed</span></h2>
    {cards}
  </section>
  {secondary_html}
  {pattern_section}
  {plan_html}
  <section class="limits">
    <h2>Limits</h2>
    <ul>{limits}</ul>
  </section>
  <div class="footer">Prospects are hypotheses based on public signals, not confirmed customers. All outreach is manual. Generated by the First Customer Finder skill.</div>
</div>
</body>
</html>"""


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate First Customer Finder HTML report")
    ap.add_argument("analysis", help="Path to analysis JSON")
    ap.add_argument("output", help="Path for output HTML")
    args = ap.parse_args()

    data = json.loads(Path(args.analysis).read_text(encoding="utf-8"))
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build(data), encoding="utf-8")
    print(f"Report written: {out}")


if __name__ == "__main__":
    main()
