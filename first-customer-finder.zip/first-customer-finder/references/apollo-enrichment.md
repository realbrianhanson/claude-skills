# Apollo Enrichment Pass

Apollo turns a qualified, evidence-backed prospect into a reachable one. It never generates prospects on its own. Public signals qualify; Apollo enriches. Keep that order or the whole system degrades into a generic lead list.

## When to run it

- The run is b2b mode, or the user asks for contacts, decision-makers, or company data
- The prospect already passed the 50+ evidence bar from public signals
- The Apollo connector is available (in Claude.ai, load the Apollo tools via tool_search first; don't guess parameter names)

If Apollo isn't connected, say so once, deliver the public-signal report anyway, and note which prospects would benefit from enrichment.

## The pass, in order

1. **Company enrichment**: for each qualified company, use organization enrichment (single or bulk for up to 10) to pull firmographics: headcount, industry, location, site, LinkedIn. This confirms the ICP match and catches disqualifiers (too big, wrong geo, wrong industry).
2. **Decision-maker lookup**: use people search scoped to the enriched company and the role the evidence points at (the person who owns the pain, not just the CEO by default). For a person already identified in a public signal, use people match to enrich that specific person instead of searching fresh.
3. **Timing reinforcement**: pull the company's job postings. A company hiring for the role the product replaces or assists is a timing signal; add it to the evidence ledger with the posting as the source.
4. **Lookalike expansion (optional, deep mode only)**: use company search built from the repeated pain patterns to surface similar companies. These have no individual evidence. They go in the secondary list, labeled speculative, scored on fit only, never mixed into the primary shortlist.

## What enrichment adds to the report

Attach an `enriched` block to the prospect JSON: company, title, headcount, industry, location, LinkedIn URL, and any business email Apollo returns. Every enriched block carries the note "Apollo-enriched. Verify before outreach." Enriched emails never appear inside the opener text; the opener leads with the public signal, and the contact path is listed separately.

## Hard guardrails

- **Read-only. Always.** Never call anything that creates or updates contacts or accounts, and never add anyone to a sequence or campaign. Those are write operations into the user's live Apollo workspace and outbound systems. They happen only if the user names the exact action and authorizes it in this conversation, and even then, confirm the target list back to them first.
- No personal (non-business) emails, no phone enrichment for cold outreach, no home addresses.
- Never use enriched data to infer or filter on sensitive traits.
- If Apollo returns nothing for a prospect, say so and leave the public channel as the recommended path. Don't substitute a guessed email pattern.
- Respect the distinction between the user's own ventures and client ventures. Never pull saved Apollo lists or sequences from one into a report for the other.

## Failure handling

If an Apollo call errors or returns unexpected shapes, log it with the feedback tool if available, retry once with corrected parameters, then move on. An unenriched qualified prospect still ships in the report. Enrichment is a bonus layer, never a blocker.
