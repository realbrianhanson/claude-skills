# Report Spec

The deliverable is a standalone HTML report generated from structured JSON. Always use the bundled generator; never hand-write the report markup.

## Generate

```bash
python3 scripts/generate_report.py analysis.json /mnt/user-data/outputs/first-customer-report.html
```

Keep `analysis.json` in the working directory unless the user asks for the raw data. After generating, open or inspect the HTML once to verify: every prospect card renders, every source link is present, scores and dimension bars show, patterns and the 7-day plan appear, and the limits section is intact. Then present the file.

## JSON schema

```json
{
  "title": "First Customers: Example App",
  "product": "Example App",
  "product_url": "https://example.com",
  "owner": "Your Name",
  "mode": "standard",
  "generated_at": "2026-07-13",
  "search_scope": "Public English-language sources, last 12 months",
  "verdict": "One-sentence answer: does this product have reachable early demand, and where is it concentrated?",
  "icp": {
    "primary": "Who the primary ideal customer is, in one line",
    "adjacent": "The adjacent ICP worth watching",
    "triggers": "The events or pains that make them buy now",
    "disqualifiers": "Who to skip even if they look close"
  },
  "prospects": [
    {
      "name": "Example Gym",
      "type": "Company",
      "stage": "Problem aware",
      "score": 82,
      "pain_signal": "Owner publicly described manually chasing overdue memberships every week.",
      "evidence": "Recent forum post describes the workflow and the hours it costs.",
      "why_fit": "The product automates the exact reminder and payment step.",
      "why_now": "Post is recent and asks how other owners handle it.",
      "source_title": "How do you handle failed payments?",
      "source_url": "https://example.com/public-post",
      "source_type": "Public forum",
      "signal_date": "2026-07-01",
      "suggested_channel": "Reply in the public thread",
      "opener": "Saw your post about chasing failed payments...",
      "caution": "Confirm the workflow is still active before pitching.",
      "dimensions": {
        "pain_strength": 5,
        "product_fit": 5,
        "timing": 4,
        "reachability": 4,
        "evidence_quality": 4
      },
      "enriched": {
        "company": "Example Gym LLC",
        "title": "Owner",
        "headcount": "11-50",
        "industry": "Fitness",
        "location": "Tampa, FL",
        "linkedin_url": "https://linkedin.com/company/example",
        "email": "owner@example.com",
        "note": "Apollo-enriched. Verify before outreach."
      }
    }
  ],
  "secondary": [
    {
      "name": "Lookalike Co",
      "reason": "Matches ICP and pain pattern 2, no individual public signal yet.",
      "source": "Apollo lookalike expansion"
    }
  ],
  "patterns": [
    {
      "title": "Manual follow-up",
      "count": 4,
      "insight": "Owners run spreadsheets and text threads after payments fail. This is the ad angle."
    }
  ],
  "outreach_plan": {
    "angle": "Lead with the pain in their words, offer a concierge test before asking for adoption.",
    "days": [
      { "day": "Day 1-2", "action": "Contact the three highest-scoring prospects with one source-based question each." },
      { "day": "Day 3-4", "action": "Follow the public threads, answer replies, book conversations." },
      { "day": "Day 5-7", "action": "Share a two-minute walkthrough only with prospects who confirmed the pain." }
    ],
    "success": "Three real conversations and one design-partner commitment inside seven days."
  },
  "limits": [
    "These are potential customers inferred from public signals, not confirmed buyers.",
    "Verify current relevance before any outreach. Keep all contact manual."
  ]
}
```

## Field rules

- `prospects` holds only primary, evidence-backed entries: valid public `source_url`, score 50+, all five dimensions filled. Sort by score, highest first; the generator features the first entry as the top prospect.
- `enriched` is optional per prospect. Include it only when Apollo data was actually pulled, and always with the verify note.
- `secondary` is optional. Speculative or lookalike entries live here and nowhere else.
- `limits` always includes the hypothesis disclaimer. Non-negotiable.
- Standard mode caps at 10 prospects, quick at 5, deep at 20.
- Dates use YYYY-MM-DD when visible, otherwise the string "date unavailable".
