# Research and Qualification Framework

Keep prospect research evidence-based, current, and respectful. This file governs how to search, what counts as a signal, and how to score.

## Product brief

Before collecting a single lead, the brief must be sharp enough to reject weak matches:

- Product and the outcome it promises
- Primary user and the economic buyer (often different people)
- The urgent job to be done
- Current alternative or workaround the prospect uses today
- The trigger that makes someone adopt now
- Geography or language constraints
- Explicit disqualifiers

If the brief can't reject anyone, it isn't done.

## Query buckets

Search several buckets rather than hammering one query. Keep individual searches short (1 to 6 words), then vary the angle. Adapt vocabulary to how the audience actually talks, not how the product page talks.

1. **Explicit demand**: "looking for," "recommend a tool," "alternative to," "does anything exist for," "is there an app that"
2. **Pain**: "takes hours," "so manual," "frustrating," "hate doing," "keeps breaking," "waste of time"
3. **Workaround**: spreadsheets, copy-paste routines, VAs doing it by hand, duct-taped scripts, "my current system is"
4. **Switching**: cancellations, migrations, "missing feature," pricing complaints, competitor frustration
5. **Timing**: launches, hiring for the relevant role, expansion, new regulation, new integration, a workflow change that makes the product suddenly relevant

Search snippets never qualify a prospect. Fetch the original page, confirm the signal is real and attributable, and note the visible date.

## Source mix

Useful public sources, weighted toward where business owners actually talk:

- Reddit and niche forums (subreddits for the trade, the tool, or the locale)
- Public social posts and replies (X, LinkedIn posts, YouTube comments on relevant videos)
- Product reviews: G2, Capterra, app marketplaces, Chrome Web Store, Shopify app store
- Google Maps and Yelp reviews of competitors (gold for local-niche and agency runs: a 2-star review describing the exact pain is a signal)
- GitHub issues and public feature requests (for dev-adjacent products)
- Public company pages, job postings, changelogs, press, local business news
- Public "looking for a tool" posts and directories

Skip private groups, gated communities, data brokers, scraped contact lists, and anything that prohibits access. Facebook groups are gated; don't try.

## Qualification score

Score each dimension 0 to 5:

- **Pain strength (25%)**: directness, severity, repetition, and the cost of the stated problem
- **Product fit (25%)**: how directly the product solves the evidenced job
- **Timing (20%)**: freshness of the signal and presence of a current trigger
- **Reachability (15%)**: a natural, relevant public or professional contact path exists
- **Evidence quality (15%)**: specificity, source reliability, confidence the signal belongs to this prospect

```text
score = pain/5*25 + fit/5*25 + timing/5*20 + reachability/5*15 + evidence/5*15
```

Read the total:

- **80 to 100**: strong first-customer candidate
- **65 to 79**: promising, validate quickly
- **50 to 64**: plausible but missing a material signal
- **Below 50**: cut from the primary shortlist

An older explicit request can still count; drop the timing score and label the date. A company that merely matches the industry with no evidenced trigger is not qualified. It can sit in a clearly labeled secondary list at most.

## Prospect stages

- **High intent**: publicly requesting a solution or actively switching
- **Problem aware**: clearly describing the pain or an expensive workaround
- **Trigger present**: a current business event makes the product relevant
- **Potential fit**: ICP match with incomplete evidence. Secondary list only.

## Evidence ledger

Record for every qualified prospect:

- Displayed company, project, or public professional name
- Source title and URL
- Visible publication date, or "date unavailable"
- Source type
- The concise pain or timing signal, paraphrased
- What was observed versus what was inferred
- Score breakdown across the five dimensions
- A freshness warning when the signal is older than about 6 months

Cite sources in the chat response whenever web research was performed.

## Opener rules

One opener per primary prospect. The shape, in order:

1. Mention the public context naturally (the post, the review, the job listing)
2. Connect it to the exact problem in their words, not marketing words
3. Explain the product in one sentence
4. Ask one low-friction question

Under 90 words. No false familiarity, no unrelated personal details, no claiming the message was sent, no private emails or phone numbers in the opener body. If the user has a personal voice skill installed, it governs tone. Otherwise write as the founder: plain, specific, human. No em dashes, no "not X but Y" contrasts, no filler phrases.

## Weak-demand verdicts

If two or more buckets come back empty after honest searching, don't pad the list. Report which signals exist, which don't, and what that means: usually that the ICP needs reframing or the product needs a sharper wedge. Recommend the next-best research angle. A true negative saves more money than a padded positive.
