---
name: lovable-production
description: Production playbook for Lovable + Supabase apps. Use to audit, harden, fix, debug, or ship any Lovable app, write batch prompts to paste into Lovable, or check security (RLS, secrets, edge functions).
---

# Lovable Production Playbook

How to take a Lovable + Supabase app from "the preview looks right" to "safe to put real customers on." Written for a non-technical builder. Define terms the first time they appear.

Operating stance: do the work, verify it, report what shipped and what's blocked on the owner. Never block progress waiting for a nice-to-have answer. Make the reasonable call and note it.

## Operating loop

Every engagement follows the same loop, whether it's a full audit or a single bug:

1. **Audit** what actually exists (code, database, live behavior). Never trust the app's own description of itself.
2. **Prioritize** findings into the P0-P3 ladder.
3. **Batch** fixes into small, single-concern units.
4. **Execute** each batch through the right channel.
5. **Verify** by reading back the critical result, not by trusting the agent's "done."
6. **Report** what shipped, what was tested, and what only the owner can do.

## Audit checklist

Inspect all four layers before proposing anything:

- **Code:** routing, auth context, protected routes, edge functions, CORS config, migrations. Search for the anon key or service_role key leaking into frontend code, hardcoded secrets, and dead code paths.
- **Database:** query `information_schema` for the real tables and columns. Cross-check against every column the code reads or writes; missing columns fail silently. Check which tables have row-level security (RLS) enabled and what the policies actually allow. An overly permissive SELECT on an internal table is a repeat offender.
- **Security:** API keys embedded in stored URLs or public rows, edge functions callable without login, public storage buckets holding private files, webhook endpoints without signature verification.
- **Live behavior:** load the deployed app. Empty sections despite data, broken images, dead automations (edge functions idle, cron not installed), and stale AI model names in pipelines are all common finds.

If you can't see the code (plain claude.ai chat with no project connected), ask the user to paste the specific files or run the audit prompts below inside Lovable, and work from what comes back.

## Priority ladder

- **P0: Stop the bleeding.** Leaked keys, missing RLS, unauthenticated functions, dead automation the product depends on. Fix this week, before anything else.
- **P1: Make the surface true.** Visible bugs: empty states, broken flows, dead links, wrong branding. The app visitors see has to actually work.
- **P2: Reliability.** Rate limits, idempotency (the same event can't double-fire), race conditions, retry handling, graceful behavior when optional secrets are missing.
- **P3: Enrich and grow.** New features, analytics, SEO. Only after P0-P2.

## Security non-negotiables

Enforce every one:

- Every table holding personal data has a `user_id` column and owner-scoped RLS. No public policies on personal tables. Non-owners are blocked in both the UI and edge functions.
- No secrets in frontend code, ever. No hardcoded keys anywhere. A missing optional secret shows a friendly "set this up" state, never a crash.
- Edge functions that touch personal data or secrets require the user to be logged in. Explicitly reject the anon key as authentication. Public-facing functions (chatbots, forms) load config server-side by id, cap input sizes, and rate-limit per user or session.
- Scheduled (cron) functions authenticate with a shared secret stored as a Supabase secret before scheduling.
- Storage buckets holding user files are private, with user-scoped paths and signed URLs. Never embed third-party API keys in stored URLs; store the file itself instead.
- Webhooks verify signatures (Stripe uses its own scheme; Resend uses svix). Payment writes are idempotent, with a unique index preventing double-counts.
- Outbound email: `reply_to` set to the owner, a real sender domain, and a CAN-SPAM signature and opt-out on anything cold. Warn in Settings until the sending domain is verified.
- Notification and milestone emails fire once, ever, per event.

## Batching rules

- One concern per batch. Security lockdown, email deliverability, and UI polish never share a batch.
- Number the items inside a batch. Give exact file paths and exact strings to change. Say "keep everything else identical" when touching shared files.
- End every code batch with "Typecheck when done."
- Route each batch through the right channel:
  - **Supabase directly (SQL editor or connector):** RLS policies, migrations, data fixes, schema checks.
  - **Lovable agent:** multi-file code changes, new components, edge function rewrites.
  - **Blocked on the owner:** anything requiring an external console or dashboard. Don't attempt; list it in the hand-off.
- Sequence so nothing depends on a blocked item. If cron needs a secret the owner hasn't set, ship everything else and stage the cron batch behind their action.

## If working through the Lovable connector (Cowork or Claude Code)

- For multi-file changes, send the message without waiting, then poll for the result. Long synchronous waits drop the connection even when Lovable finishes the work.
- A dropped or "failed" call does NOT mean the work failed. Check the project state before re-sending. Re-running a completed batch causes damage.
- Jobs sit in "accepted" for a while before processing. Poll patiently.
- After any batch that touched something security-critical, read the final state of that file and confirm the fix holds. Trust the diff, not the summary.

## Prompt patterns

**Scoped batch prompt** (paste into Lovable):

```
[Batch name]. Numbered items only, no scope creep.

1. [Fix] in [exact file path]: [exact change, exact strings]. Keep everything else identical.
2. ...

Typecheck when done.
```

**Rollback prompt** (use verbatim when a change breaks the app):

```
The last change broke the app. Do not add features. Diagnose and repair only.

Identify what changed in the last step and what errors appear in build/preview/logs. Fix the regression and nothing else. Return a summary of the root cause and the repair.
```

**Security audit prompt** (paste into Lovable when you can't see the code yourself):

```
Audit this project for security. Do not change anything yet. Report:

1. Any API keys, secrets, or service_role keys in frontend code.
2. Every table that stores personal data, and whether it has user_id and RLS policies restricting rows to the owner.
3. Every edge function, and whether it requires authentication.
4. Every storage bucket, and whether it is public or private.
5. Every webhook endpoint, and whether it verifies signatures.

List findings as P0 (critical), P1 (visible bug), P2 (reliability). Do not fix anything until I approve the batch.
```

**Final QA prompt** (last batch of any hardening pass):

```
Final pass: correctness, safety, reliability, documentation. No new features.

1. Build/compile clean; imports and paths correct.
2. Auth/RLS: every personal table has user_id; no public RLS on personal tables; non-owner blocked in UI and edge functions.
3. Secrets: none in frontend; none hardcoded; missing optional secrets show graceful setup states.
4. Storage: private buckets, user-scoped paths, signed URLs.
5. [App-specific core flows still work: list them.]
6. Optional features degrade gracefully when not configured.
7. Regenerate the schema doc (DATA_SCHEMA.md) from information_schema so it matches reality, including storage bucket status.
8. Write/update the README: architecture, required and optional secrets, deployment steps, what to verify before trusting it with real data.

Return: what changed, what was tested, remaining limitations.
```

## Verification standards

- Query `information_schema` after migrations; confirm every column the code touches exists.
- Read back the critical file after security batches. "Verified, the lockdown holds" only after seeing the code.
- Check live behavior for P1 fixes: does the section render, does the image load, does the form submit.
- Track before/after numbers when the work is pipeline-related. Concrete numbers go in the report.

## Hand-off list (things only the owner can do)

Always close with this list when it applies. Standard items:

- Rotate any leaked API keys in the external console (Google Cloud, OpenAI, etc.) and restrict the new keys to the app's domain.
- Set secrets in Supabase (Project Settings → Edge Functions → Secrets): payment keys, email keys, webhook secrets, cron secret, and per-app keys.
- Verify the sending domain in the email provider and create webhooks (delivered, opened, bounced, complained) pointing at the app's webhook function.
- Sign up for third-party APIs and paid tiers.
- Publish: batches commit to preview; the owner pushes live after clicking through.

Give exact console paths and exact endpoint URLs so each item is a 2-minute task, and say what each one unblocks.

## Report format

End every session with:

**Shipped (N batches):** numbered list, one line per batch, concrete outcomes with numbers where possible.

**Only you can do:** the hand-off list.

**Remaining / deferred:** anything consciously punted, with the priority it was assigned.

## Stack defaults

Vite + React + TypeScript + Tailwind + shadcn on the frontend. Supabase: Postgres with RLS, Deno edge functions, Storage, pg_cron for scheduled jobs (secret-authenticated). Resend for email. Stripe for payments. When an AI feature is dead, check the model name first; a stale model string is a repeat root cause.
